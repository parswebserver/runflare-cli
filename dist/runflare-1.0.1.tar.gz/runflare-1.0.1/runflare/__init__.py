VERSION = "1.0.1"
NAME = "runflare_cli"

if __name__ == "__main__":
    print(VERSION)