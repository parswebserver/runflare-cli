# runflare

install runflare CLI

#pip install runflare

CLI for Runflare Paas
