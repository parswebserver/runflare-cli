

class Data_Manager:
    pass


