VERSION = "1.0.0"
NAME = "runflare_cli"

if __name__ == "__main__":
    print(VERSION)